package Calculator;

public class evenNumberslessthan50 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x=2;
		{
			
		while (x<50){
			System.out.println(x);
			x=x+2;
		}}}
	}


