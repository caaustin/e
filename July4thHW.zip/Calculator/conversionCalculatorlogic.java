package Calculator;

import java.util.Scanner;

public abstract class conversionCalculatorlogic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Celsius");
	}
		
		public abstract void feettoinches();
		
		public abstract void celsiustofahrenheit();
		
	}
	
