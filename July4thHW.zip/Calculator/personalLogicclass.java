package Calculator;

public class personalLogicclass {{

	 
System.out.println("Andrew Austin");
System.out.println("954-707-1775");
System.out.println("Coral Springs");}

public static void main(String[] args) {
	// TODO Auto-generated method stub   
	}

}
