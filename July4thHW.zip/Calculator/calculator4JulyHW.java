package Calculator;

import java.util.Scanner;

public class calculator4JulyHW {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("Press 1 for Feet to Inches conversion");

Scanner keyboard = new Scanner (System.in);

int a = keyboard.nextInt();

if (a==1);{
	
	System.out.println("Feet to Inches after conversion");
	System.out.println("Please enter Feet");
	Scanner keyboard1 = new Scanner (System.in);
	
	int b = keyboard1.nextInt();
	System.out.println(b*12);
}
	}

}
