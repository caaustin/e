package Calculator;

public class nameStudentTeacher {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a = 2;
				
		int b = 2;
		
		if (a==b) {
			System.out.println("Andrew Austin");
		}
		else {
		System.out.println("Arfath Mohammed");
		}
	}

}
