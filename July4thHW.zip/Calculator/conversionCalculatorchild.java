package Calculator;

import java.util.Scanner;

public class conversionCalculatorchild extends conversionCalculatorlogic{
	
	public static void main(String[]args) {

conversionCalculatorchild obj1 = new conversionCalculatorchild();
obj1.feettoinches();
	}
	public void feettoinches() {
	}

	{
	System.out.println("Press 1: For Feet to Inches Conversion");

	Scanner keyboard = new Scanner (System.in);

	int z = keyboard.nextInt ();

	if(z==1);	
		
		{
		
	System.out.println("Feet to Inches after Conversion");
			
	System.out.println("Please enter Feet");
	Scanner keyboard1 = new Scanner (System.in);

	int w = keyboard1.nextInt ();

	System.out.println(w*12);		
}
}

	public void celsiustofahrenheit() {
		// TODO Auto-generated method stub
		
	}

		// TODO Auto-generated method stub
		
	}


