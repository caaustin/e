package Calculator;

public class oddNumberslessthan40inheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        //define the limit
        int limit = 50;
       
        System.out.println("Printing Odd numbers between 1 and " + limit);
       
        for(int a=1; a <= limit; a++){
               
                if( a % 2 != 0){
                        System.out.print(a + " ");
                }
        }
}}
	


