package Calculator;

import java.util.Scanner;

public class multiplication9Table {

	public static void main(String[] args) {
		// TODO Auto-generated method

	{
System.out.println("Press 1 mutiply any number by 9");

Scanner keyboard = new Scanner (System.in);

int a = keyboard.nextInt();

if (a==1);{
	
	System.out.println("Conversion by 9");
	System.out.println("Please enter number to be multiplied");
	Scanner keyboard1 = new Scanner (System.in);
	
	int b = keyboard1.nextInt();
	System.out.println(b*9);
}
	}

}}