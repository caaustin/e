package Calculator;

public class gradingApplication {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub

int x=0;

if (x<=100&&x>90){
	System.out.println("You Got an A!");
}
else if (x<=89&&x>80){
	System.out.println("You Got a B!");
}
else if (x<=79&&x>70){
	System.out.println("You got a C!");
}
	}

}
