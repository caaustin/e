package Calculator;

import java.util.Scanner;

public class conversionCalculatorchild1 extends conversionCalculatorlogic{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
conversionCalculatorchild1 obj2 = new conversionCalculatorchild1();
obj2.celsiustofahrenheit();
	}
	public void celsiustofahrenheit(){
	}				
	{	
	System.out.println("Press 2: For Celsius to Fahrenheit Conversion");
		
	Scanner keyboard = new Scanner (System.in);

	int k = keyboard.nextInt ();
		
	if(k==2);
	
	{
							
		System.out.println("Celsius to Fahrenheit after coversion");
		
		System.out.println("Please enter Degrees Celsius");
		Scanner keyboard2 = new Scanner (System.in);
		
		int m = keyboard2.nextInt ();
		
		System.out.println(k*9/5+32);}
	}
	public void feettoinches() {
		// TODO Auto-generated method stub
		
	}}


